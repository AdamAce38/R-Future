## Deprecated
The files in this folder are deprecated and will be removed in the future. The prefered way to access the completion scripts is through `step completion <shell>`.
