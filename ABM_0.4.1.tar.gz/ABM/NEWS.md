# Version 0.3

Remove agent from a population. This allows agent deaths and moving between populations.

# Version 0.2
  
initializers for the state of agents in the population

# Version 0.1
  
Initial implementation
  
  
